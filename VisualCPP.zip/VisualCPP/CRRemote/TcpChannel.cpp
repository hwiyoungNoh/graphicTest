#include "StdAfx.h"
#include "TcpChannel.h"

CTcpChannel::CTcpChannel(void)
{
}

CTcpChannel::~CTcpChannel(void)
{
}
