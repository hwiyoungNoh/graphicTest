//////////////////////////////////////////////////////////
// Copyright �2015 Colorimetry Research, Inc. All Rights Reserved Worldwide. 	
// Version 1.26
//
// License: 
// This code is provided as a demonstration of the Remote Communication Software Development Kit.
// 
// This software is provided "as is" with no warranties of any kind.
// 
//////////////////////////////////////////////////////////
// Remote Communication.h : main header file for the Remote Communication application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CRemoteCommunicationApp:
// See Remote Communication.cpp for the implementation of this class
//

class CRemoteCommunicationApp : public CWinApp
{
public:
	CRemoteCommunicationApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

public:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CRemoteCommunicationApp theApp;